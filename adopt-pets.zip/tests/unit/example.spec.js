import { shallowMount } from '@vue/test-utils'

import Home from '@/views/Home'

describe('Testing Home component', () => {
  const wrapper = shallowMount(Home)
  // const vm = wrapper.vm
  it('renders the heading', () => {
    expect(wrapper.html()).toContain('<h1>Adopt a Pet</h1>')
  })

  it('Home component has an add pet button', () => {
    expect(wrapper.find('button').exists()).toBe(true)
  })
})
