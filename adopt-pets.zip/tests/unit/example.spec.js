import { shallowMount } from '@vue/test-utils'
import Home from '@/views/Home'

describe('Testing Home component', () => {
  const wrapper = shallowMount(Home)
  // const vm = wrapper.vm
  it('renders the correct title of Home page', () => {
    expect(wrapper.html()).toContain('<h1>Adopt a new best friend.</h1>')
  })

  it('check if it has an add new pet button', () => {
    expect(wrapper.find('button').exists()).toBe(true)
  })

  it('button should click the form', () => {
    expect(wrapper.vm.showPetForm).toBe(false)
    const button = wrapper.find('button')
    button.trigger('click')
    expect(wrapper.vm.showPetForm).toBe(true)
  })
})
