export default [
  {
    name: 'Fish',
    breed: 'tuxedo',
    species: 'cat',
    gender: 'male',
    age: 20,
    color: 'black/white',
    weight: 13,
    location: 'fourside',
    notes: 'Sweet kitty. He loves getting his belly rubbed.'
  },
  {
    name: 'Henry',
    breed: 'tabby',
    species: 'cat',
    gender: 'male',
    age: 20,
    color: 'orange/white',
    weight: 17,
    location: 'threed',
    notes: 'Super friendly'
  },
  {
    name: 'Roger',
    breed: 'tabby',
    species: 'cat',
    gender: 'male',
    age: 20,
    color: 'gray',
    weight: 15,
    location: 'threed',
    notes: 'Super friendly'
  },
  {
    name: 'Kitkat',
    breed: 'bombay',
    species: 'cat',
    gender: 'female',
    age: 0.9,
    color: 'black',
    weight: 9,
    location: 'threed',
    notes: 'Super friendly'
  }
]
